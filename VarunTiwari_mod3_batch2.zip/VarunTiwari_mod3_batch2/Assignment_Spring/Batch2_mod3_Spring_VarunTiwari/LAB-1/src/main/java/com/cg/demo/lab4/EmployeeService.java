package com.cg.demo.lab4;

public interface EmployeeService {
	public Employee getDetails(int empId);
}
